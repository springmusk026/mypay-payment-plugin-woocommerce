=== MyPay Payment Gateway for WooCommerce ===
Contributors: yourname
Tags: woocommerce, payment gateway, mypay, checkout, payment
Requires at least: 5.6
Tested up to: 6.3
Stable tag: 1.0.0
Requires PHP: 7.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A secure and professional payment gateway for WooCommerce that integrates with MyPay Checkout API.

== Description ==

The MyPay Payment Gateway for WooCommerce allows you to accept payments via MyPay Checkout API. This plugin provides a seamless integration between your WooCommerce store and MyPay payment services.

= Features =

* Accept payments via MyPay
* Secure payment processing
* Automatic order status updates
* Detailed transaction logging
* Admin dashboard for payment status verification
* Support for both test and live environments

= Requirements =

* WordPress 5.6 or higher
* WooCommerce 5.0 or higher
* PHP 7.3 or higher
* MyPay merchant account

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/mypay-payment-gateway` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to WooCommerce > Settings > Payments and configure the MyPay Payment Gateway.
4. Enter your MyPay API credentials (API Key, Merchant ID, Username, and Password).

== Frequently Asked Questions ==

= Does this plugin work with the latest version of WooCommerce? =

Yes, this plugin is regularly tested with the latest version of WooCommerce.

= Can I test payments before going live? =

Yes, the plugin includes a test mode that allows you to test payments using the MyPay sandbox environment.

= How do I get MyPay API credentials? =

You need to contact MyPay at merchant@mypay.com.np to request merchant signup.

== Screenshots ==

1. MyPay payment gateway settings
2. Checkout page with MyPay payment option
3. Order details with MyPay payment information

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release

